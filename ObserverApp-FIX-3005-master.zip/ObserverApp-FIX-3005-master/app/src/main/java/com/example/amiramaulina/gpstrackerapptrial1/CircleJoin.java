package com.example.amiramaulina.gpstrackerapptrial1;

/**
 * Created by Amira
 */

public class CircleJoin
{
    public String circlememberid;

    public CircleJoin(String circlememberid)
    {
        this.circlememberid = circlememberid;

    }

    public CircleJoin()
    {}



}
