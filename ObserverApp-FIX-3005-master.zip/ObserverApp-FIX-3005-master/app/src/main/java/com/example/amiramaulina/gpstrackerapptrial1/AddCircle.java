package com.example.amiramaulina.gpstrackerapptrial1;

/**
 * Created by Amira Maulina
 */

public class AddCircle
{
    public AddCircle(String name, String isSharing, String lat, String lng) {
        this.name = name;
        this.isSharing = isSharing;
        this.lat = lat;
        this.lng = lng;

    }

    public String name,isSharing,lat,lng;

    public AddCircle()
    {}


}
